
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import serializers
from .models import *
from .serializer import *
from rest_framework.views import APIView
# from rest_framework.permissions import IsAuthenticated




# class StudentAPI(APIView):
#     # permission_classes = [IsAuthenticated]
#     def get(self,request):
#         student_objs=Student_Demo.objects.all()
#         serializer=StudentSerializer(student_objs,many=True)
#         return Response({'status':200,"payload": serializer.data})
#     def post(self,request):
#         # data=request.data
#         # print(data)
#         serializer=StudentSerializer(data=request.data)
#         if not serializer.is_valid():
#             return Response({'status':403,'error':serializer.errors,'message':'Some Thing Went Wrong'})
#         serializer.save()
#         return Response({'status':200,"payload": serializer.data,"message":'Your Data Is Saved'}) 
#     def patch(self,request):
#         try:
#             id=request.GET.get('id')
#             print("-==-=-=-=-=-==-=-=",id)
#             student_objs=Student_Demo.objects.get(id=id)
#             serializer=StudentSerializer(student_objs,data=request.data,partial=True)
#             if not serializer.is_valid():
#                 return Response({'status':403,'error':serializer.errors,'message':'Some Thing Went Wrong'})
#             serializer.save()
#             return Response({'status':200,"payload": serializer.data,"message":'Your Data Is Saved'}) 
#         except Exception as e:
#             return Response({'status':403,"message":'Invalid ID'}) 
    # def put(self,request):
    #     pass
    # def delete(self,request):
    #     try:
    #         id=request.GET.get('id')
    #         student_objs=Student_Demo.objects.get(id=request.data)
    #         student_objs.delete()
    #         return Response({'status':200,"message":'Your Data Is Deleted'}) 
    #     except Exception as e:
    #         return Response({'status':403,"message":'Invalid ID'}) 





































@api_view(['GET'])
def get_Student(request):
    student_objs=Student_Demo.objects.all()
    serializer=StudentSerializer(student_objs,many=True)
    return Response({'status':200,"payload": serializer.data})


@api_view(['GET'])
def get_Student_id(request,id):
    student_objs=Student_Demo.objects.get(id=id)
    serializer=StudentSerializer(student_objs)
    return Response({'status':200,"payload": serializer.data})


@api_view(['POST'])
def post_Student(request):
    data=request.data
    print(data)
    serializer=StudentSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({'status':403,'error':serializer.errors,'message':'Some Thing Went Wrong'})
    serializer.save()
    return Response({'status':200,"payload": serializer.data,"message":'Your Data Is Saved'}) 



@api_view(['PUT','PATCH'])
def put_Student(request,id):
    try:
        student_objs=Student_Demo.objects.get(id=id)
        data=request.data
        print(data)
        serializer=StudentSerializer(student_objs,data=request.data,partial=True)
        if not serializer.is_valid():
            return Response({'status':403,'error':serializer.errors,'message':'Some Thing Went Wrong'})
        serializer.save()
        return Response({'status':200,"payload": serializer.data,"message":'Your Data Is Saved'}) 
    except Exception as e:
        return Response({'status':403,"message":'Invalid ID'}) 
    
    

@api_view(['DELETE'])
def delete_Student(request,id):
    try:
        student_objs=Student_Demo.objects.get(id=id)
        student_objs.delete()
        return Response({'status':200,"message":'Your Data Is Deleted'}) 
    except Exception as e:
        return Response({'status':403,"message":'Invalid ID'}) 




@api_view(['GET'])
def get_Book(request):
    book=Book.objects.all()
    serializer=BookSerializer(book,many=True)
    return Response({'status':200,"payload": serializer.data})













































# from django.shortcuts import render
# from rest_framework.response import Response
# from rest_framework.decorators import api_view
# from django.contrib.auth import authenticate
# from django.views.decorators.csrf import csrf_exempt
# from rest_framework.authtoken.models import Token
# from rest_framework.decorators import api_view, permission_classes
# from rest_framework.permissions import AllowAny
# from rest_framework.status import (
#     HTTP_400_BAD_REQUEST,
#     HTTP_404_NOT_FOUND,
#     HTTP_200_OK
# )
# from rest_framework.response import Response
# # In views.py or wherever you are working with sessions
# from django.contrib.sessions.models import Session
# from django.contrib.sessions.backends.db import SessionStore
# from datetime import timedelta
# from django.utils import timezone
# from rest_framework.authtoken.models import Token

# from django.db import models



# # from .models import Data
# # from .serializer import DataSerializer

# # # Create your views here.
# # @api_view(['GET'])
# # def getData(request):
# #     app = Data.objects.all()
# #     serializer = DataSerializer(app, many=True)
# #     return Response(serializer.data)


# # @api_view(['POST'])
# # def postData(request):
# #     serializer = DataSerializer(data=request.data)
# #     if serializer.is_valid():
# #         serializer.save()
# #     return Response(serializer.data)



# class ExtendedToken(Token):
#     expires = models.DateTimeField(null=True, blank=True)

#     def set_expiration(self, duration=timedelta(minutes=1)):
#         self.expires = timezone.now() + duration
#         self.save()
        
        
        
# @csrf_exempt
# @api_view(["POST"])
# @permission_classes((AllowAny,))
# def login(request):
#     username = request.data.get("username")
#     password = request.data.get("password")
#     print("===",username)
#     print("===",password)
#     if username is None or password is None:
#         return Response({'error': 'Please provide both username and password'},
#                         status=HTTP_400_BAD_REQUEST)
#     user = authenticate(username=username, password=password)
#     if not user:
#         return Response({'error': 'Invalid Credentials'},
#                         status=HTTP_404_NOT_FOUND)
#     token_duration = timedelta(minutes=1)
#     token, _ = ExtendedToken.objects.get_or_create(user=user)
#     token.set_expiration(duration=token_duration)
#     print(token)
    
#     request.session["Token"] = token.key
    
#     # Session['Token'] = token
#     return Response({'token': token.key},
#                     status=HTTP_200_OK)
    
    
# @csrf_exempt
# @api_view(["GET"])
# def sample_api(request):
#     data = {'sample_data': 123}
#     token = request.session.get("Token")
#     print("===",token)
#     return Response(data, status=HTTP_200_OK)
