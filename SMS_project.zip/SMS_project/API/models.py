# accounts/models.py

# from django.contrib.auth.models import AbstractUser
from django.db import models

# class CustomUser(AbstractUser):
#     email = models.EmailField(unique=True)

#     def __str__(self):
#         return self.username

class Student_Demo(models.Model):
    name=models.CharField(max_length=100)
    age=models.IntegerField(default=18)
    father_name=models.CharField(max_length=100)
    
    
class Category(models.Model):
    category_name=models.CharField(max_length=100)
    

class Book(models.Model):
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    book_title=models.CharField(max_length=100)
    