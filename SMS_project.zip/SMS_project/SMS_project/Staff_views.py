from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from Admin.models import Course,Session_Year,CustomUser,Student,Staff,Subject,Staff_Notification,Staff_leave,Staff_Feedback,Attendance_Report,Attendance,StudentResult
from django.contrib import messages
import socket
from SMS_project.Hod_views import get_Authenticate



@login_required(login_url='/')
def HOME(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    # student_count=Student.objects.all().count()
    # staff_count=Staff.objects.all().count()
    # subject_count=Subject.objects.all().count()
    # course_count=Course.objects.all().count()
    
    # student_gender_male=Student.objects.filter(gender='Male').count()
    # student_gender_female=Student.objects.filter(gender='Female').count()
    
    # context={
    #     'student_count':student_count,
    #     'staff_count':staff_count,
    #     'subject_count':subject_count,
    #     'course_count':course_count,
    #     'student_gender_male':student_gender_male,
    #     'student_gender_female':student_gender_female
    # }
    
    return render(request,'Staff/home.html')




#Staff send Notification 

@login_required(login_url='/')
def STAFF_NOTIFICATIONS(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    staff=Staff.objects.filter(admin=request.user.id)
    for i in staff:
        staff_id=i.id
        notification=Staff_Notification.objects.filter(staff_id=staff_id)
        context={
            'notification':notification
        }
        return render(request,'Staff/Staff_Notification.html',context)

@login_required(login_url='/')
def STAFF_NOTIFICATION_MARK_AS_DONE(request,status):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    notification=Staff_Notification.objects.get(id=status)
    notification.status=1
    notification.save()
    return redirect("staff_notifications")



#Apply for Leave 


@login_required(login_url='/')
def STAFF_APPLY_LEAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    staff=Staff.objects.filter(admin=request.user.id)
    
    for i in staff:
        staff_id=i.id
        staff_leave_history=Staff_leave.objects.filter(staff_id=staff_id)
        
        context={
            'staff_leave_history':staff_leave_history,
        }
        return render(request,'Staff/Staff_apply_leave.html',context)

@login_required(login_url='/')
def STAFF_APPLY_LEAVE_SAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method=="POST":
        leave_date=request.POST.get('leave_date')
        leave_message=request.POST.get('leave_message')
        
        staff=Staff.objects.get(admin=request.user.id)
        
        leave=Staff_leave(
            staff_id=staff,
            data=leave_date,
            message=leave_message,
        )
        leave.save()
        messages.success(request,"Leave Successfully Send !!")
        return redirect("staff_apply_leave")
    
   
   
# Send Feedback
  
@login_required(login_url='/')
def STAFF_FEEDBACK(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    staff_id=Staff.objects.get(admin=request.user.id)
    
    feedback_history=Staff_Feedback.objects.filter(staff_id=staff_id)
    
    context={
        'feedback_history':feedback_history
    }
    return render(request,'Staff/Staff_feedback.html',context)


@login_required(login_url='/')
def STAFF_FEEDBACK_SAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method=="POST":
        feedback_message=request.POST.get('feedback_message')
        staff=Staff.objects.get(admin=request.user.id)
        feedback=Staff_Feedback(
            staff_id=staff,
            feedback=feedback_message,
            feedback_reply="",            
        )
        feedback.save()
        messages.success(request,"Feedback Successfully Send !!")
    return redirect("staff_feedback")




# Attendance

@login_required(login_url='/')
def STAFF_TAKE_ATTENDANCE(request): 
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/')   
    staff_id=Staff.objects.get(admin=request.user.id)
    subject=Subject.objects.filter(staff=staff_id)
    session_year=Session_Year.objects.all()


    action=request.GET.get('action')
    get_subject=None
    get_session_year=None
    students=None
    if action is not None:
        if request.method=="POST":
            subject_id=request.POST.get('subject_id')
            session_id=request.POST.get('session_id')
            
            get_subject=Subject.objects.get(id=subject_id)
            get_session_year=Session_Year.objects.get(id=session_id)
            
            subject=Subject.objects.filter(id=subject_id)
            for i in subject:
                student_id=i.course.id
                students=Student.objects.filter(course_id=student_id)
    
    context={
        'subject':subject,
        'session_year':session_year,
        'get_subject':get_subject,
        'get_session_year':get_session_year,
        'action':action,
        'students':students
    }

    return render(request,'Staff/Take_attendance.html',context)


@login_required(login_url='/')
def STAFF_SAVE_ATTENDANCE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method=="POST":
        student_id=request.POST.getlist('student_id')
        attendance_date=request.POST.get('attendance_date')
        session_id=request.POST.get('session_id')
        subject_id=request.POST.get('subject_id')
        
        get_subject=Subject.objects.get(id=subject_id)
        get_session_year=Session_Year.objects.get(id=session_id)
        
        attendance=Attendance(
            subject_id=get_subject,
            attendance_data=attendance_date,
            session_Year_id=get_session_year
        )
        attendance.save()
        for std_id in student_id:
            p_students=Student.objects.get(id=std_id)
            attendance_report=Attendance_Report(
                student_id=p_students,
                attendance_id=attendance
            )
            attendance_report.save()

    messages.success(request,"Attendance Taken Successfully !!")
    return redirect('staff_take_attendance')





@login_required(login_url='/')
def STAFF_VIEW_ATTENDANCE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    staff_id=Staff.objects.get(admin=request.user.id)
    subject=Subject.objects.filter(staff=staff_id)
    session_year=Session_Year.objects.all()
    action=request.GET.get('action')


    get_subject=None
    get_session_year=None
    attendance_report=None
    attendance_date=None
    if action is not None:
        if request.method=="POST":
            subject_id=request.POST.get('subject_id')
            session_id=request.POST.get('session_id')
            attendance_date=request.POST.get('attendance_date')
            
            get_subject=Subject.objects.get(id=subject_id)
            get_session_year=Session_Year.objects.get(id=session_id)
            
            attendance=Attendance.objects.filter(subject_id=get_subject,attendance_data=attendance_date)
            
            for i in attendance:
                attendance_id=i.id
                attendance_report=Attendance_Report.objects.filter(attendance_id=attendance_id)
                
    
    context={
        'subject':subject,
        'session_year':session_year,
        'get_subject':get_subject,
        'get_session_year':get_session_year,
        'action':action,
        'attendance_date':attendance_date,
        'attendance_report':attendance_report
    }
    
    return render(request,'Staff/View_attendance.html',context)
    
            
            
#Result

def STAFF_ADD_RESULT(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    staff = Staff.objects.get(admin = request.user.id) 
    subjects = Subject.objects.filter(staff_id = staff) 
    session_year = Session_Year.objects.all() 
    action = request.GET.get('action') 
    get_subject = None 
    get_session = None 
    students = None 
    # print("-=-=-=-=--=-=-=-=-",subjects)
    if action is not None: 
        # print("1")
        if request.method == "POST": 
        #    print("2")
           subject_id = request.POST.get('subject_id') 
           session_year_id = request.POST.get('session_year_id') 
           get_subject = Subject.objects.get(id = subject_id) 
           get_session = Session_Year.objects.get(id = session_year_id) 
           subjects = Subject.objects.filter(id = subject_id) 
        #    print("====",subjects)
           for i in subjects: 
               student_id = i.course.id 
               students = Student.objects.filter(course_id = student_id) 
    context = { 
        'subjects':subjects, 
        'session_year':session_year, 
        'action':action, 
        'get_subject':get_subject, 
        'get_session':get_session, 
        'students':students, 
    } 
    return render(request,'Staff/add_result.html',context)      


def STAFF_SAVE_RESULT(request): 
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method == "POST": 
        subject_id = request.POST.get('subject_id') 
        session_year_id = request.POST.get('session_year_id') 
        student_id = request.POST.get('student_id') 
        assignment_mark = request.POST.get('assignment_mark') 
        Exam_mark = request.POST.get('Exam_mark') 
        get_student = Student.objects.get(admin = student_id) 
        get_subject = Subject.objects.get(id=subject_id) 
        check_exist = StudentResult.objects.filter(subject_id=get_subject, student_id=get_student).exists() 
        if check_exist: 
            result = StudentResult.objects.get(subject_id=get_subject, student_id=get_student) 
            result.assignment_mark = assignment_mark 
            result.exam_mark = Exam_mark 
            result.save() 
            messages.success(request, "Successfully Updated Result !!") 
            return redirect('staff_add_result') 
        else: 
            result = StudentResult(student_id=get_student, subject_id=get_subject, exam_mark=Exam_mark, 
                                   assignment_mark=assignment_mark) 
            result.save() 
            messages.success(request, "Successfully Added Result !!") 
            return redirect('staff_add_result')




