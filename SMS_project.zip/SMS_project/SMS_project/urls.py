
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from django.views.decorators.csrf import csrf_exempt # Add this line
from graphene_django.views import GraphQLView # Add this line

from .import views,Hod_views,Staff_views,Student_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path("graphql", csrf_exempt(GraphQLView.as_view(graphiql=True))), # Add this line
    path('API/', include('API.urls')),
    path('base/',views.BASE,name='base'),
    
    #Login Path
    path('',views.LOGIN,name='login'),
    path('doLogin',views.doLogin,name='doLogin'),
    path('doLogout',views.doLogout,name='logout'),
    
    #profile Update
    path('Profile',views.PROFILE,name='profile'),
    path('Profile/update',views.PROFILE_UPDATE,name='profile_update'),
    
    
    
    ##############################################  This is hod Panel  #########################################
    
    
    path('Hod/home',Hod_views.HOME,name='Hod_home'),
    
    #Student
    path('Hod/Student/Add',Hod_views.ADD_STUDENT,name='Add_Student'),
    path('Hod/Student/View',Hod_views.VIEW_STUDENT,name='View_Student'),
    path('Hod/Student/Edit/<str:id>',Hod_views.Edit_STUDENT,name='Edit_Student'),
    path('Hod/Student/Update',Hod_views.UPDATE_STUDENT,name='Update_Student'),
    path('Hod/Student/Delete/<str:id>',Hod_views.DELETE_STUDENT,name='Delete_Student'),
    
    #Course
    path('Hod/Course/Add',Hod_views.ADD_COURSE,name='Add_course'),
    path('Hod/Course/View',Hod_views.VIEW_COURSE,name='View_course'),
    path('Hod/Course/Edit/<str:id>',Hod_views.EDIT_COURSE,name='Edit_course'),
    path('Hod/Course/Update',Hod_views.UPDATE_COURSE,name='Update_course'),
    path('Hod/Course/Delete/<str:id>',Hod_views.DELETE_COURSE,name='Delete_course'),
    
    #Staff
    path('Hod/Staff/Add',Hod_views.ADD_STAFF,name='Add_Staff'),
    path('Hod/Staff/View',Hod_views.VIEW_STAFF,name='View_Staff'),
    path('Hod/Staff/Edit/<str:id>',Hod_views.Edit_STAFF,name='Edit_Staff'),
    path('Hod/Staff/Update',Hod_views.UPDATE_STAFF,name='Update_Staff'),
    path('Hod/Staff/Delete/<str:id>',Hod_views.DELETE_STAFF,name='Delete_Staff'),
    
    #Subject
    path('Hod/Subject/Add',Hod_views.ADD_SUBJECT,name='Add_Subject'),
    path('Hod/Subject/View',Hod_views.VIEW_SUBJECT,name='View_Subject'),
    path('Hod/Subject/Edit/<str:id>',Hod_views.Edit_SUBJECT,name='Edit_Subject'),
    path('Hod/Subject/Update',Hod_views.UPDATE_SUBJECT,name='Update_Subject'),
    path('Hod/Subject/Delete/<str:id>',Hod_views.DELETE_SUBJECT,name='Delete_Subject'),
    
    #session
    path('Hod/Session/Add',Hod_views.ADD_SESSION,name='Add_Session'),
    path('Hod/Session/View',Hod_views.VIEW_SESSION,name='View_Session'),
    path('Hod/Session/Edit/<str:id>',Hod_views.Edit_SESSION,name='Edit_Session'),
    path('Hod/Session/Update',Hod_views.UPDATE_SESSION,name='Update_Session'),
    path('Hod/Session/Delete/<str:id>',Hod_views.DELETE_SESSION,name='Delete_Session'),
    
    #notification TO Staff
    path('Hod/Satff/Send_Notification',Hod_views.STAFF_SEND_NOTIFICATION,name='staff_send_notification'),
    path('Hod/Satff/Save_Notification',Hod_views.STAFF_SAVE_NOTIFICATION,name='staff_save_notification'),
    
    #notification to student 
    path('Hod/Student/Send_Notification',Hod_views.STUDENT_SEND_NOTIFICATION,name='student_send_notification'),
    path('Hod/Student/Save_Notification',Hod_views.STUDENT_SAVE_NOTIFICATION,name='student_save_notification'),
    
    #Staff Leave
    path('Hod/Satff/Leave_view',Hod_views.STAFF_LEAVE_VIEW,name='staff_leave_view'),
    path('Hod/Satff/Approve_leave/<str:id>',Hod_views.STAFF_APPROVE_LEAVE,name='staff_approve_leave'),
    path('Hod/Satff/Disapprove_leave/<str:id>',Hod_views.STAFF_DISAPPROVE_LEAVE,name='staff_disapprove_leave'),
    
    
    #Student Leave
    path('Hod/Student/Leave_view',Hod_views.STUDENT_LEAVE_VIEW,name='student_leave_view'),
    path('Hod/Student/Approve_leave/<str:id>',Hod_views.STUDENT_APPROVE_LEAVE,name='student_approve_leave'),
    path('Hod/Student/Disapprove_leave/<str:id>',Hod_views.STUDENT_DISAPPROVE_LEAVE,name='student_disapprove_leave'),
    
    #Staff Feedback
    path('Hod/Staff/feedback',Hod_views.STAFF_FEEDBACK,name='hod_staff_feedback'),
    path('Hod/Staff/feedback/Save',Hod_views.STAFF_FEEDBACK_SAVE,name='hod_staff_feedback_save'),
    
    #Student Feedback
    path('Hod/Student/feedback',Hod_views.STUDENT_FEEDBACK,name='hod_student_feedback'),
    path('Hod/Student/feedback/Save',Hod_views.STUDENT_FEEDBACK_SAVE,name='hod_student_feedback_save'),
    
    #View Attendance
    path('Hod/View/Attendance',Hod_views.VIEW_ATTENDANCE,name='view_attendance'),
    
    
    
    
    
    ##############################################  This is Staff Panel  #########################################
    
    
    path('Staff/home',Staff_views.HOME,name='Staff_home'),
    
    #notification
    path('Staff/Notifications',Staff_views.STAFF_NOTIFICATIONS,name='staff_notifications'),
    path('Staff/mark_as_done/<str:status>',Staff_views.STAFF_NOTIFICATION_MARK_AS_DONE,name='staff_notification_mark_as_done'),
    path('Staff/Apply_leave',Staff_views.STAFF_APPLY_LEAVE,name='staff_apply_leave'),
    path('Staff/Apply_leave_save',Staff_views.STAFF_APPLY_LEAVE_SAVE,name='staff_apply_leave_save'),
    
    #Staff Feedback
    path('Staff/Feedback',Staff_views.STAFF_FEEDBACK,name='staff_feedback'),
    path('Staff/Feedback/Save',Staff_views.STAFF_FEEDBACK_SAVE,name='staff_feedback_save'),
    
    #staff Attendance
    path('Staff/Take_Attendance',Staff_views.STAFF_TAKE_ATTENDANCE,name='staff_take_attendance'),
    path('Staff/Save_Attendance',Staff_views.STAFF_SAVE_ATTENDANCE,name='staff_save_attendance'),
    path('Staff/View_Attendance',Staff_views.STAFF_VIEW_ATTENDANCE,name='staff_view_attendance'),
    
    #Result
    path('Staff/Add/Result',Staff_views.STAFF_ADD_RESULT,name='staff_add_result'),
    path('Staff/Save/Result',Staff_views.STAFF_SAVE_RESULT,name='staff_save_result'),
    
    
    
    
    
    
    
    ##############################################  This is Student Panel  #########################################
    
    
    path('Student/home',Student_views.HOME,name='Student_home'),
    
    ####notification
    path('Student/Notifications',Student_views.STUDENT_NOTIFICATIONS,name='student_notifications'),
    path('Student/mark_as_done/<str:status>',Student_views.STUDENT_NOTIFICATION_MARK_AS_DONE,name='student_notification_mark_as_done'),
    path('Student/Apply_leave',Student_views.STUDENT_APPLY_LEAVE,name='student_apply_leave'),
    path('Student/Apply_leave_save',Student_views.STUDENT_APPLY_LEAVE_SAVE,name='student_apply_leave_save'),
    
    
    #Student Feedback
    path('Student/Feedback',Student_views.STUDENT_FEEDBACK,name='student_feedback'),
    path('Student/Feedback/Save',Student_views.STUDENT_FEEDBACK_SAVE,name='student_feedback_save'),
    
    
    #Student view Attendance
    path('Student/View_Attendance',Student_views.STUDENT_VIEW_ATTENDANCE,name='student_view_attendance'),
    
    #student view result
    path('Student/View_Result',Student_views.STUDENT_VIEW_RESULT,name='student_view_result'),
    
    
    
    
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
