from django.urls import path
from . import views
from django.conf import settings
# from .views import StudentAPI

urlpatterns = [
# path('', views.getData),
# path('post/', views.postData),
# path('login', views.login),
# path('sampleapi', views.sample_api)
path('get_Student', views.get_Student),
path('get_Student_id/<id>', views.get_Student_id),
path('post_Student', views.post_Student),
path('put_Student/<id>', views.put_Student),
path('delete_Student/<id>', views.delete_Student),
# path('get_Book', views.get_Book)
#  path('students', StudentAPI.as_view())
    # path('students/<int:id>', StudentAPI.as_view())
]