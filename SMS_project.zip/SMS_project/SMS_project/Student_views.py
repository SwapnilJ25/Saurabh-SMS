from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from Admin.models import Course,Session_Year,CustomUser,Student,Staff,Subject,Staff_Notification,Student_Notification,Student_leave,Student_Feedback,Subject,Attendance,Attendance_Report,StudentResult
from django.contrib import messages
import socket
from SMS_project.Hod_views import get_Authenticate


@login_required(login_url='/')
def HOME(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
       
    # student_count=Student.objects.all().count()
    # staff_count=Staff.objects.all().count()
    # subject_count=Subject.objects.all().count()
    # course_count=Course.objects.all().count()
    
    # student_gender_male=Student.objects.filter(gender='Male').count()
    # student_gender_female=Student.objects.filter(gender='Female').count()
    
    # context={
    #     'student_count':student_count,
    #     'staff_count':staff_count,
    #     'subject_count':subject_count,
    #     'course_count':course_count,
    #     'student_gender_male':student_gender_male,
    #     'student_gender_female':student_gender_female
    # }
    
    return render(request,'Student/home.html')



@login_required(login_url='/')
def STUDENT_NOTIFICATIONS(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    student=Student.objects.filter(admin=request.user.id)
    for i in student:
        student_id=i.id
        notification=Student_Notification.objects.filter(student_id=student_id)
        context={
            'notification':notification
        }
        return render(request,'Student/Student_Notification.html',context)

@login_required(login_url='/')
def STUDENT_NOTIFICATION_MARK_AS_DONE(request,status):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    notification=Student_Notification.objects.get(id=status)
    notification.status=1
    notification.save()
    return redirect("student_notifications")



@login_required(login_url='/')
def STUDENT_APPLY_LEAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    student=Student.objects.filter(admin=request.user.id)
    
    for i in student:
        student_id=i.id
        student_leave_history=Student_leave.objects.filter(student_id=student_id)
        
        context={
            'student_leave_history':student_leave_history,
        }
        return render(request,'Student/Student_apply_leave.html',context)


@login_required(login_url='/')
def STUDENT_APPLY_LEAVE_SAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method=="POST":
        leave_date=request.POST.get('leave_date')
        leave_message=request.POST.get('leave_message')
        
        student=Student.objects.get(admin=request.user.id)
        
        leave=Student_leave(
            student_id=student,
            data=leave_date,
            message=leave_message,
        )
        leave.save()
        messages.success(request,"Leave Successfully Send !!")
        return redirect("student_apply_leave")




# Send Feedback
  
@login_required(login_url='/')
def STUDENT_FEEDBACK(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    student_id=Student.objects.get(admin=request.user.id)
    
    feedback_history=Student_Feedback.objects.filter(student_id=student_id)
    
    context={
        'feedback_history':feedback_history
    }
    return render(request,'Student/Student_feedback.html',context)


@login_required(login_url='/')
def STUDENT_FEEDBACK_SAVE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    if request.method=="POST":
        feedback_message=request.POST.get('feedback_message')
        student=Student.objects.get(admin=request.user.id)
        feedback=Student_Feedback(
            student_id=student,
            feedback=feedback_message,
            feedback_reply="",            
        )
        feedback.save()
        messages.success(request,"Feedback Successfully Send !!")
    return redirect("student_feedback")




# Student Attendance


@login_required(login_url='/')
def STUDENT_VIEW_ATTENDANCE(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    student=Student.objects.get(admin=request.user.id)    
    subjects=Subject.objects.all().filter(course=student.course_id)
    action=request.GET.get('action')
    get_subject=None
    attendance_report=None
    if action is not None:
        if request.method=="POST":
            subject_id=request.POST.get('subject_id')
            get_subject=Subject.objects.get(id=subject_id)
            

            attendance_report=Attendance_Report.objects.filter(student_id=student,attendance_id__subject_id=subject_id)
    context={
        'subjects':subjects,
        'get_subject':get_subject,
        'action':action,
        'attendance_report':attendance_report
    }
    return render(request,'Student/View_attendance.html',context)


# Student Result


@login_required(login_url='/')
def STUDENT_VIEW_RESULT(request):
    try:
        get_Authenticate(request,request.session.get('token'),request.session.get('token'),socket.gethostbyname(socket.gethostname()))
    except:
        return redirect('/') 
    mark=None
    student=Student.objects.get(admin=request.user.id)
    result=StudentResult.objects.filter(student_id=student)
    for i in result:
        assignment_mark=i.assignment_mark
        exam_mark=i.exam_mark
        
        mark=assignment_mark+exam_mark
    context={
       'result' :result,
       'mark':mark
    }
    return render(request,'Student/View_result.html',context)


