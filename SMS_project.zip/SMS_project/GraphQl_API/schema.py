import graphene
from graphene_django import DjangoObjectType
from .models import Book 
from Admin.models import CustomUser
import cryptocode
import jwt
import socket
from datetime import datetime, timedelta, timezone
from calendar import timegm
from user_agents import parse
from django.contrib.auth.hashers import check_password


key = "Bearer"


def get_Token( loginid,  password, timeStamp,UserAgent,user_ip):
    token_payload = {

        "loginid": loginid,

        "password": password,
        # "curr_time":timegm(datetime.now(tz=timezone.utc).utctimetuple()),
        "curr_time": timeStamp,
        "expired_time": timegm((datetime.now(tz=timezone.utc) + timedelta(minutes=20)).utctimetuple()),
        "exp": timegm((datetime.now(tz=timezone.utc) + timedelta(minutes=20)).utctimetuple()),
        "iss": TokenParam('iss'),
        "Aud": TokenParam('Aud'),
        "User-Agent":UserAgent,
        "user_ip":user_ip
    }
    return jwt.encode(token_payload, key, algorithm="HS256").decode('utf-8')


def get_refresh_token(loginid, password, timeStamp):
    refresh_payload = {

        "loginid": loginid,
        "password": password,
        "curr_time": timeStamp,
        # "exp": timegm((datetime.now(tz=timezone.utc) + timedelta(minutes=2)).utctimetuple()),
    }
    return encryptionAnddecryption('e', str(refresh_payload))


def encryptionAnddecryption(var1, text):
    if (var1 == 'e'):
        return cryptocode.encrypt(text, "saurabh")
    else:
        return cryptocode.decrypt(text, "saurabh")


def TokenParam(var1):
    if (var1 == 'iss'):
        return "www.accordfintech.com"
    else:
        return "http://127.0.0.1:8000/graphql/"



    
class CustomInput(graphene.InputObjectType):

    loginid = graphene.String()
    password = graphene.String()
    # role = graphene.String()
    # userid = graphene.Int()
    # roleid = graphene.Int()
    # isactive = graphene.String()
    # entryby = graphene.Int()
    # doe = graphene.DateTime()
    # modifiedby = graphene.Int()
    # datemodified = graphene.DateTime()
    token = graphene.String()
    refresh_token = graphene.String()


class Token(graphene.InputObjectType):
    tokenStr = graphene.String()
    refreshToken = graphene.String()
    # userId = graphene.String()
    # roleId = graphene.String()
    # roleName = graphene.String()


def get_Authenticate(token,userAgent,user_ip):
    
        token_value = token.startswith('Bearer')
        # print("+++++>>>>>", token_value)
        if token_value:
            token = token.strip("Bearer?")
            token = token.lstrip().rstrip()
            # print("-------->>>>>", token)
            token_payload = jwt.decode(token, 'secret', algorithm=[
                               "HS256"], verify=False)
            # print("///*****",encryptionAnddecryption('d',token_payload['user_ip']))
            if token_payload['User-Agent']!=userAgent or encryptionAnddecryption('d',token_payload['user_ip'])!=user_ip:
                 raise Exception(
                        "Wrong User Agent 5")
            else:
                try:
                    header_data = jwt.get_unverified_header(token)
                    # print("inside try")
                except:
                    raise Exception(
                             "The current user is not authorized to access this resource. 3")
            # print("++++++++++++>>>>>>>>>>",len(token))    
        else:
            raise Exception(
                "The current user is not authorized to access this resource. 2")
    



def getTimeInHours(token):
    token_payload = jwt.decode(token, 'secret', algorithm=[
                               "HS256"], verify=False)
    if 'User-Agent' in token_payload:
        token_exp_time_In_Sec = int(token_payload['expired_time'])
        token_exp_time_In_HHMMSS = datetime.fromtimestamp(
            token_exp_time_In_Sec)
        return token_exp_time_In_HHMMSS
    else:
        # print("\nelse")
        raise Exception(
            "The current user is not authorized to access this resource. 4")
        

def get_current_device(UserAgent):
    user_agent = parse(UserAgent)
    # print("+++>>>>>",user_agent.device.family)
    return user_agent.os.family
    
    
def checkTokenExpiredOrNot(datetime_):
    if datetime.now() > datetime_:
        return True
    return False


class BookType(DjangoObjectType): 
    class Meta:
        model = Book
        fields = "__all__"

class CoustomType(DjangoObjectType):
    class Meta:
        model = CustomUser
        fields = ('id', 'username', 'email', 'first_name', 'last_name', 'is_superuser')


def get_refresh_token( loginid, password, timeStamp):
    refresh_payload = {
        "loginid": loginid,
        "password": password,
        "curr_time": timeStamp,
        # "exp": timegm((datetime.now(tz=timezone.utc) + timedelta(minutes=2)).utctimetuple()),
    }
    return encryptionAnddecryption('e', str(refresh_payload))



class Query(graphene.ObjectType):
    all_books = graphene.List(BookType)
    user = graphene.Field(CoustomType, id=graphene.ID(required=True))
    book = graphene.Field(BookType, book_id=graphene.Int())

    def resolve_all_books(self, info, **kwargs):
        return Book.objects.all()
   

    def resolve_user(self, info, id):
        try:
            return CustomUser.objects.get(id=id)
        except CustomUser.DoesNotExist:
            return None
    

    def resolve_book(self, info, book_id):
        return Book.objects.get(pk=book_id)


class BookInput(graphene.InputObjectType):
    id = graphene.ID()
    title = graphene.String()
    author = graphene.String()
    year_published = graphene.String()
    review = graphene.Int() 
    
    
class CreateBook(graphene.Mutation):
    class Arguments:
        book_data = BookInput(required=True)

    book = graphene.Field(BookType)

    @staticmethod
    def mutate(root, info, book_data=None):
        book_instance = Book( 
            title=book_data.title,
            author=book_data.author,
            year_published=book_data.year_published,
            review=book_data.review
        )
        book_instance.save()
        return CreateBook(book=book_instance)




class UpdateBook(graphene.Mutation):
    class Arguments:
        book_data = BookInput(required=True)

    book = graphene.Field(BookType)

    @staticmethod
    def mutate(root, info, book_data=None):

        book_instance = Book.objects.get(pk=book_data.id)

        if book_instance:
            book_instance.title = book_data.title
            book_instance.author = book_data.author
            book_instance.year_published = book_data.year_published
            book_instance.review = book_data.review
            book_instance.save()

            return UpdateBook(book=book_instance)
        return UpdateBook(book=None)




class DeleteBook(graphene.Mutation):
    class Arguments:
        id = graphene.ID()

    book = graphene.Field(BookType)

    @staticmethod
    def mutate(root, info, id):
        book_instance = Book.objects.get(pk=id)
        book_instance.delete()

        return None
   
 
class login(graphene.Mutation):
    token = graphene.String()
    refresh_token = graphene.String()


    class Arguments:
        loginid = CustomInput().loginid
        password = CustomInput().password

    @staticmethod
    def mutate(root, info, loginid, password):
        if len(loginid) == 0 or len(password) == 0:
            raise Exception("Invalid Credentials")
        else:

            if not CustomUser.objects.filter(email=loginid).exists():
                raise Exception('Not Register Yet , Register First!!!')
            user_instance = CustomUser.objects.get(email=loginid)
            password_match = check_password(password, user_instance.password)
            if password_match!=True:
                raise Exception("Password Invalid Credentials!!")
            loginid = user_instance.email
            currtime = timegm(datetime.now(tz=timezone.utc).utctimetuple())
            user_ip=socket.gethostbyname(socket.gethostname())
            user_agent = parse(info.context.META.get('HTTP_USER_AGENT')).os.family
            token = get_Token(loginid=loginid, 
                              password=user_instance.password, timeStamp=currtime,UserAgent=user_agent,user_ip=encryptionAnddecryption('e',str(user_ip)))
            token=f"Bearer {token}"
            refresh_token = get_refresh_token(
                loginid=loginid, password=encryptionAnddecryption('e', password), timeStamp=currtime)
            return login(token=token, refresh_token=refresh_token)



class refresh_tok(graphene.Mutation):
    token = graphene.String()
    refresh_token = graphene.String()

    class Arguments:
        token = graphene.String()
        refreshToken = graphene.String()

    @staticmethod
    def mutate(root, info, token, refreshToken):
        old_token_payload = jwt.decode(
            token, 'secret', verify=False, algorithm=["HS256"])
        user_agent = parse(info.context.META.get('HTTP_USER_AGENT')).os.family
        if 'expired_time' in old_token_payload:
            try:
                header_data = jwt.get_unverified_header(token)
                # The above code is using the `print` function to output a blank line.
                # print("Befor_heder")
                return getJwtToken(token, refreshToken, True,user_agent)

            except jwt.ExpiredSignatureError:
                # print("in Exception")
                # print(token)
                old_token_payload = jwt.decode(
                    token, 'secret', verify=False, algorithm=["HS256"])
                # print(old_token_payload)
                old_token_exp_time_In_HHMMSS = getTimeInHours(
                    token)+timedelta(minutes=20)
                ch = checkTokenExpiredOrNot(old_token_exp_time_In_HHMMSS)
                if ch == True:
                    return refresh_tok(token='Token-Expired', refresh_token='')
                else:
                    return getJwtToken(token, refreshToken, False,user_agent)
        else:
            # print("\nelse")
            raise Exception('Please Enter valid Token.')


def getJwtToken(token, refreshToken, flag,user_agent):
    # decode token
    if flag == True:
        # if expired or wrong will give error
        old_token_payload = jwt.decode(token, key, algorithms="HS256")
    else:
        # if expired or wrong will give error
        old_token_payload = jwt.decode(
            token, key, algorithms="HS256", verify=False)
    # print('\ndecoded old token: ', old_token_payload)

    # decode refresh token
    refeshtoken_string = encryptionAnddecryption('d', refreshToken)
    # convert refreshtoken to dictionary form
    refeshtoken_dict = eval(refeshtoken_string.replace("'", "\""))
    # print('\nDecrypted refreshtoken :', refeshtoken_dict)

    loginid_token = CustomUser.objects.filter(
        email=old_token_payload['loginid']).exists()
    loginid_refresh = CustomUser.objects.filter(
        email=refeshtoken_dict['loginid']).exists()
    logintime_stamp = old_token_payload['curr_time']
    refreshtime_stamp = refeshtoken_dict['curr_time']
    # print('logintime_stamp', logintime_stamp)
    # print('reftime_stamp', refreshtime_stamp)

    # print('token_exp 1', getTimeInHours(token))
    old_token_exp_time_In_HHMMSS = getTimeInHours(token)+timedelta(minutes=20)
    # print('token_exp 2', old_token_exp_time_In_HHMMSS)
    if datetime.now() > old_token_exp_time_In_HHMMSS:

        return refresh_tok(token='Token-Expired', refresh_token='')
    currtime = timegm(datetime.now(tz=timezone.utc).utctimetuple())
    
    if loginid_token == loginid_refresh and logintime_stamp == refreshtime_stamp:

        new_token = get_Token(loginid=old_token_payload['loginid'],
                              password=old_token_payload['password'], timeStamp=currtime,UserAgent=user_agent,user_ip=old_token_payload['user_ip'])
        new_token=f"Bearer {new_token}"
        # print("\nnewtoken: ", new_token)
        # print("\ndecoded newtoken: ",jwt.decode(new_token, "secret", algorithms=["HS256"]), options={"verify_exp":False})

        refreshtoken = get_refresh_token( loginid=refeshtoken_dict['loginid'], password=encryptionAnddecryption(
            'e', refeshtoken_dict['password']), timeStamp=currtime)
        # print("\nrefreshtoken: ", refreshtoken)
        # print("\ndecrypt refreshtoken: ",encryptionAnddecryption('d',refreshtoken))

        return refresh_tok(token=new_token, refresh_token=refreshtoken)
    else:
        return refresh_tok(token="Invalid-token", refresh_token='')



class Mutation(graphene.ObjectType):
    create_book = CreateBook.Field()
    update_book = UpdateBook.Field()
    delete_book = DeleteBook.Field()
    login = login.Field()
    RefreshToken = refresh_tok.Field()
    # user_authentication = mutations.ObtainJSONWebToken.Field()


schema = graphene.Schema(query=Query, mutation=Mutation)









   
    