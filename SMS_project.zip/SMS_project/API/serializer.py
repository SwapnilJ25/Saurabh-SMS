from rest_framework import serializers
from .models import *


# class DataSerializer(serializers.ModelSerializer):
#     class Meta:
#         model=Data
#         fields=('name','description')

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model=Student_Demo
        # fields=['name','age']
        # exclude=['name']
        fields = '__all__' 
    def validate(self, data):
        if data['age'] < 18:
            raise serializers.ValidationError({'error':"AGE cannot be less than 18"})
        if data['name']:
            for n in data['name']:
                if n.isdigit():
                    raise serializers.ValidationError({'error':"Name can not contain Number..."})
        return data
    
    

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields=['category_name']
        
 

class BookSerializer(serializers.ModelSerializer):
    category=CategorySerializer()
    class Meta:
        model=Book
        fields='__all__'