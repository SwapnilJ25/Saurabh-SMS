from typing import Any
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model
from django.contrib.auth.base_user import AbstractBaseUser
from django.http.request import HttpRequest


class EmailBackEnd(ModelBackend):
    def authenticate(self,  username=None, password=None, **kwargs):
            UserModel = get_user_model()
            # print("1")
            try:
                # print("2")
                user = UserModel.objects.get(email=username)
                # print("3")
            except UserModel.DoesNotExist:
                # print("4")
                return None
            else:
                # print("5")
                if user.check_password(password):
                    # print("6")
                    return user
            # print("7")
            return None
 